import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import * as Papa from 'papaparse';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {
  @Output() userDetails = new EventEmitter<{ username: string, role: string }>(); // Add this line
  gateCode: string = '';
  username: string = '';
  role: string = '';
  userFound: boolean = false;

  constructor(private http: HttpClient, private router: Router) {
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras.state as { gateCode: string };
    this.gateCode = state?.gateCode || '';
  }

  ngOnInit() {
    if (this.gateCode !== 'Guest') {
      this.loadUserData();
    } else {
      this.username = 'Guest';
      this.role = 'Guest';
      this.userFound = true;
      this.userDetails.emit({ username: this.username, role: this.role }); // Emit user details
    }
  }

  loadUserData() {
    this.http.get(environment.loginPath, { responseType: 'text' })
      .subscribe((csvData) => {
        Papa.parse(csvData, {
          header: true,
          skipEmptyLines: true,
          complete: (result) => {
            const users = result.data;
            const user = users.find((u: any) => u.gate_code === this.gateCode);
            if (user) {
              this.username = user.username;
              this.role = user.role;
              this.userFound = true;
              this.userDetails.emit({ username: this.username, role: this.role }); // Emit user details
            }
          }
        });
      }, (error) => {
        console.error('Error loading CSV data:', error);
      });
  }
}
