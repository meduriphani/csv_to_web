import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-code-review',
  templateUrl: './code-review.component.html',
  styleUrls: ['./code-review.component.css']
})
export class CodeReviewComponent implements OnInit {
  @Input() data: any; // Add this line to accept the data input

  constructor() { }

  ngOnInit(): void {
  }
}
