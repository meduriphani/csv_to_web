import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlMComponent } from './control-m.component';

describe('ControlMComponent', () => {
  let component: ControlMComponent;
  let fixture: ComponentFixture<ControlMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ControlMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
