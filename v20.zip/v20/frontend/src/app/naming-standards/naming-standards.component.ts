import { Component, OnInit, Input } from '@angular/core';
import axios from 'axios';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-naming-standards',
  templateUrl: './naming-standards.component.html',
  styleUrls: ['./naming-standards.component.css']
})
export class NamingStandardsComponent implements OnInit {
  @Input() data: any;
  templateName: string = '';
  namingStandards: any = {
    TemplateName: '',
    Field1: '',
    Field2: '',
    Field3: '',
    Field4: '',
    Field5: ''
  };
  templates: any[] = [];
  newFieldName: string = '';

  ngOnInit() {
    this.loadTemplates();
  }

  loadTemplates() {
    axios.get(`${environment.backendApiUrl}/templates`)
      .then(response => {
        console.log('Response data:', response.data); // Debugging log
        this.templates = response.data.split('\n').map(row => {
          const fields = row.split(',');
          return fields.reduce((acc, field, index) => {
            acc[`Field${index}`] = field.trim().replace(/"/g, ''); // Trim whitespace and remove double quotes
            return acc;
          }, { TemplateName: fields[0].trim().replace(/"/g, '') }); // Trim whitespace and remove double quotes
        }).filter(template => template.TemplateName); // Filter out templates with blank names
        console.log('Parsed templates:', this.templates); // Debugging log
      })
      .catch(error => {
        console.error('Error fetching templates:', error);
      });
  }

saveTemplate() {
  if (!this.templateName.trim()) {
    alert('Template Name is required');
    return;
  }

  // Ensure all fields are populated
  Object.keys(this.namingStandards).forEach(key => {
    if (!this.namingStandards[key].trim()) {
      this.namingStandards[key] = 'N/A'; // Assign a default value if the field is empty
    }
  });

  this.namingStandards.TemplateName = this.templateName.trim(); // Ensure TemplateName is set
  axios.post(`${environment.backendApiUrl}/templates`, this.namingStandards)
    .then(response => {
      alert(response.data);
      this.loadTemplates();
    })
    .catch(error => {
      if (error.response && error.response.status === 400) {
        alert(error.response.data); // Display the error message from the server
      } else {
        console.error('Error adding template:', error);
      }
    });
}

updateTemplate() {
  if (!this.templateName.trim()) {
    alert('Template Name is required');
    return;
  }

  // Ensure all fields are populated
  Object.keys(this.namingStandards).forEach(key => {
    if (!this.namingStandards[key].trim()) {
      this.namingStandards[key] = 'N/A'; // Assign a default value if the field is empty
    }
  });

  // Adjust field sequences
  const adjustedNamingStandards = { TemplateName: this.templateName.trim() };
  let fieldIndex = 0;
  Object.keys(this.namingStandards).forEach(key => {
    if (key !== 'TemplateName') {
      adjustedNamingStandards[`Field${fieldIndex}`] = this.namingStandards[key];
      fieldIndex++;
    }
  });

  axios.put(`${environment.backendApiUrl}/templates`, adjustedNamingStandards)
    .then(response => {
      alert(response.data);
      this.loadTemplates();
    })
    .catch(error => {
      console.error('Error updating template:', error);
    });
}




applyTemplate() {
  const selectedTemplate = this.templates.find(template => template.TemplateName === this.templateName);
  if (selectedTemplate) {
    this.namingStandards = { TemplateName: selectedTemplate.TemplateName };
    let fieldIndex = 0;
    Object.keys(selectedTemplate).forEach(key => {
      if (key !== 'TemplateName') {
        this.namingStandards[`Field${fieldIndex}`] = selectedTemplate[key];
        fieldIndex++;
      }
    });
    alert('Template applied successfully!');
  } else {
    alert('Template not found!');
  }
}

selectTemplate(templateName: string) {
  const selectedTemplate = this.templates.find(template => template.TemplateName === templateName);
  if (selectedTemplate) {
    this.namingStandards = { TemplateName: selectedTemplate.TemplateName };
    let fieldIndex = 1;
    Object.keys(selectedTemplate).forEach(key => {
      if (key !== 'TemplateName') {
        this.namingStandards[`Field${fieldIndex}`] = selectedTemplate[key];
        fieldIndex++;
      }
    });
  } else {
    alert('Template not found!');
  }
}



  addField() {
    const fieldCount = Object.keys(this.namingStandards).length;
    const newFieldName = `Field${fieldCount}`;
    this.namingStandards[newFieldName] = '';
  }

  deleteField(fieldName: string) {
    delete this.namingStandards[fieldName];
  }

  clearFields() {
    this.templateName = '';
    this.namingStandards = {
      TemplateName: '',
      Field1: '',
      Field2: '',
      Field3: '',
      Field4: '',
      Field5: ''
    };
    this.newFieldName = '';
  }

  getFieldKeys() {
    return Object.keys(this.namingStandards).filter(key => key !== 'TemplateName');
  }
}
