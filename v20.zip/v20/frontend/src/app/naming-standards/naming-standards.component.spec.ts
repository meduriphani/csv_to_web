import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NamingStandardsComponent } from './naming-standards.component';

describe('NamingStandardsComponent', () => {
  let component: NamingStandardsComponent;
  let fixture: ComponentFixture<NamingStandardsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NamingStandardsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NamingStandardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
