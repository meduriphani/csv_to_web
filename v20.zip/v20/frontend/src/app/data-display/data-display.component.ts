import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { NgxPaginationModule } from 'ngx-pagination';
import * as Papa from 'papaparse'; // Use PapaParse for better CSV parsing

@Component({
  selector: 'app-data-display',
  templateUrl: './data-display.component.html',
  styleUrls: ['./data-display.component.css']
})
export class DataDisplayComponent implements OnInit {
  data: any[] = [];
  filteredData: any[] = [];
  filterText: string = '';
  displayedColumns: string[] = [];
  page: number = 1;
  totalRecords: number = 0; // Property to store total record count
  filteredRecordsCount: number = 0; // Property to store filtered record count
  isFilterApplied: boolean = false; // New property to track if filter is applied

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.http.get(environment.csvPath, { responseType: 'text' })
      .subscribe((csvData) => {
        const results: any[] = [];
        Papa.parse(csvData, {
          header: true,
          skipEmptyLines: true,
          complete: (result) => {
            this.data = result.data;
            this.filteredData = this.data;
            this.displayedColumns = Object.keys(this.data[0]).slice(0, 10); // Display the first 10 columns
            this.totalRecords = this.data.length; // Update total record count
            this.filteredRecordsCount = this.filteredData.length; // Update filtered record count
          }
        });
      }, (error) => {
        console.error('Error loading CSV data:', error);
      });
  }

  applyFilter() {
    this.filteredData = this.data.filter(row => {
      return this.displayedColumns.some(column => row && row[column] && row[column].includes(this.filterText));
    });
    this.filteredRecordsCount = this.filteredData.length; // Update filtered record count
    this.isFilterApplied = true; // Set filter applied flag to true
  }

  clearFilter() {
    this.filterText = '';
    this.filteredData = this.data;
    this.filteredRecordsCount = this.filteredData.length; // Update filtered record count
    this.isFilterApplied = false; // Set filter applied flag to false
  }

  exportData() {
    const headers = this.displayedColumns.join(',');
    const csvData = this.filteredData.map(row => this.displayedColumns.map(column => row[column]).join(',')).join('\n');
    const fullCsvData = `${headers}\n${csvData}`;
    const blob = new Blob([fullCsvData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    const fileName = this.filterText ? `filtered_data_${this.filterText}.csv` : 'filtered_data.csv';
    a.href = url;
    a.download = fileName;
    a.click();
    window.URL.revokeObjectURL(url);
  }

 viewDetails(row: any) {
   this.router.navigate(['/details'], { state: { data: row } });
 }


  getColumnWidth(column: string): string {
    switch (column) {
      case 'SourceLocation':
      case 'DestinationLocation':
        return '30px'; // Wider width for these columns
      case 'Column1':
        return '30px'; // Example width for Column1
      case 'Column2':
        return '30px'; // Example width for Column2
      // Add cases for other columns with unique widths
      default:
        return '20px'; // Default width for other columns
    }
  }
}
