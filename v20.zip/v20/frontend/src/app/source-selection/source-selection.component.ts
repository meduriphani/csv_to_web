import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import * as Papa from 'papaparse';

@Component({
  selector: 'app-source-selection',
  templateUrl: './source-selection.component.html',
  styleUrls: ['./source-selection.component.css']
})
export class SourceSelectionComponent implements OnInit {
  Math = Math;

  environment: 'qa' | 'prod' = 'qa';
  onlineHostsData: any[] = [];
  offlineHostsData: any[] = [];
  filteredData: any[] = [];

  currentPage: number = 1;
  pageSize: number = 50;
  filterText: string = '';
  username: string = '';
  password: string = '';
  activeTab: 'online' | 'offline' = 'offline';
  bearerToken: string = '';
  hostsResponse: any = {};
paging = {
  totalItems: 0,
  pageSize: this.pageSize,
  currentPage: this.currentPage
};


  constructor(private router: Router, private http: HttpClient) {
    const navigation = this.router.getCurrentNavigation();
    this.environment = 'qa';
  }

  ngOnInit() {
    this.loadOfflineHostsCsv();
  }

  loadOfflineHostsCsv() {
    const fileName = `${this.environment}_hosts.csv`;
    this.http.get(`${environment.backendApiUrl}/hosts/${fileName}`, { responseType: 'text' })
      .subscribe(data => {
        const parsedData = this.parseCsv(data);
        this.offlineHostsData = parsedData;
        this.filteredData = parsedData;
        this.paging.totalItems = this.filteredData.length;
      }, error => {
        console.error('Error loading offline hosts CSV:', error);
      });
  }

  parseCsv(data: string): any[] {
    const results = [];
    Papa.parse(data, {
      header: true,
      skipEmptyLines: true,
      complete: (parsedData) => {
        results.push(...parsedData.data);
      }
    });
    return results;
  }

  filterData() {
    const source = this.activeTab === 'online' ? this.onlineHostsData : this.offlineHostsData;
    this.filteredData = source.filter(item =>
      Object.keys(item).some(key =>
        item[key]?.toString().toLowerCase().includes(this.filterText.toLowerCase())
      )
    );
    this.currentPage = 1;
    this.paging.totalItems = this.filteredData.length;
  }

  clearFilter() {
    this.filterText = '';
    this.filteredData = this.activeTab === 'online' ? this.onlineHostsData : this.offlineHostsData;
    this.currentPage = 1;
    this.paging.totalItems = this.filteredData.length;
  }

  selectSourceAppName(rowData: any) {
    if (!rowData) return;
    this.router.navigate(['/details'], {
      state: {
        selectedSourceAppName: rowData.Name,
        environment: this.environment,
        data: rowData
      }
    });
  }

  get paginatedData() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    return this.filteredData.slice(startIndex, startIndex + this.pageSize);
  }

  nextPage() {
    if (this.currentPage * this.pageSize < this.filteredData.length) {
      this.currentPage++;
      this.paging.currentPage = this.currentPage;
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.paging.currentPage = this.currentPage;
    }
  }

  setActiveTab(tab: 'online' | 'offline') {
    this.activeTab = tab;
    this.filteredData = tab === 'online' ? this.onlineHostsData : this.offlineHostsData;
    this.currentPage = 1;
    this.filterText = '';
    this.paging.totalItems = this.filteredData.length;
  }

 onSubmit() {
   const apiUrl = this.environment === 'qa' ? '/api' : '/api-prod';
   const tokenUrl = `${apiUrl}/v1/token`;
   const hostsUrl = `${apiUrl}/v1/hosts`;
   const server_host = environment.baseUrls[this.environment];

   const data = `grant_type=password&password=${encodeURIComponent(this.password)}&server_host=${encodeURIComponent(server_host)}&username=${encodeURIComponent(this.username)}`;

   this.http.post(tokenUrl, data, {
     headers: {
       'Accept': 'application/json',
       'Content-Type': 'application/x-www-form-urlencoded'
     }
   }).subscribe(
     (response: any) => {
       this.bearerToken = response['access_token'];
      alert("Bearer-Token: "+this.bearerToken);
       this.http.get(hostsUrl, {
         headers: {
           'Authorization': `Bearer ${this.bearerToken}`,
           'Accept': 'application/json'
         }
       }).subscribe(
         (hostsResponse: any) => {
           this.hostsResponse = hostsResponse;
           this.onlineHostsData = (hostsResponse.items || []).map(item => {
             const key = Object.keys(item)[0]; // e.g., "FileSystem", "SSHFTP", etc.
             return item[key]; // return the inner object
           });
           if (this.activeTab === 'online') {
             this.filteredData = this.onlineHostsData;
             this.paging.totalItems = this.filteredData.length;
             this.currentPage = 1;
           }
           console.log('Online Hosts:', this.onlineHostsData);
         },
         error => {
           console.error('Error fetching online hosts:', error.message || error);
         }
       );
     },
     error => {
       console.error('Error fetching token:', error.message || error);
     }
   );
 }

}

