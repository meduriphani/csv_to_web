import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-change-management',
  templateUrl: './change-management.component.html',
  styleUrls: ['./change-management.component.css']
})
export class ChangeManagementComponent implements OnInit {
  @Input() data: any;
  changeTicket: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    // Load initial data if necessary
  }

  submitChangeTicket() {
    this.http.get(environment.csvPath, { responseType: 'text' })
      .subscribe((data) => {
        const rows = data.split('\n');
        const updatedRows = rows.map(row => {
          const columns = row.split(',');
          if (columns[0] === 'selectedRowID') { // Replace with actual row ID logic
            columns[columns.length - 1] = this.changeTicket;
          }
          return columns.join(',');
        });
        const updatedCsvData = updatedRows.join('\n');
        const blob = new Blob([updatedCsvData], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'data.csv';
        a.click();
        window.URL.revokeObjectURL(url);
        alert('Change ticket submitted successfully!');
      });
  }
}
