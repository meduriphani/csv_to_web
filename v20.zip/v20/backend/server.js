const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const { Parser } = require('json2csv');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());
app.use(cors());

const templatesPath = process.env.NAMING_TEMPLATES_PATH;

app.get('/templates', (req, res) => {
  fs.readFile(templatesPath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading file:', err);
      res.status(500).send('Error reading file');
      return;
    }
    const cleanedData = data.replace(/"/g, ''); // Remove double quotes
    res.send(cleanedData);
  });
});

app.get('/template-names', (req, res) => {
  fs.readFile(templatesPath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading file:', err);
      res.status(500).send('Error reading file');
      return;
    }
    const templateNames = data.split('\n').map(row => {
      const fields = row.split(',');
      return fields[0].trim(); // Extract TemplateName
    }).filter(templateName => templateName); // Filter out blank names
    res.send(templateNames);
  });
});

app.post('/templates', (req, res) => {
  const newTemplate = req.body;

  // Check if the template name is empty
  if (!newTemplate.TemplateName.trim()) {
    res.status(400).send('Template Name is required');
    return;
  }

  fs.readFile(templatesPath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading file:', err);
      res.status(500).send('Error reading file');
      return;
    }

    const templates = data.split('\n').map(row => {
      const fields = row.split(',');
      return fields.reduce((acc, field, index) => {
        acc[`Field${index}`] = field.trim(); // Trim whitespace
        return acc;
      }, { TemplateName: fields[0].trim() }); // Trim whitespace
    });

    // Check if a template with the same name already exists
    const existingTemplate = templates.find(template => template.TemplateName === newTemplate.TemplateName);
    if (existingTemplate) {
      res.status(400).send('A template with this name already exists');
      return;
    }

    // Ensure all fields are populated
    Object.keys(newTemplate).forEach(key => {
      if (!newTemplate[key].trim()) {
        newTemplate[key] = 'N/A'; // Assign a default value if the field is empty
      }
    });

    const json2csvParser = new Parser({ header: true }); // Include headers
    let csv = json2csvParser.parse([newTemplate]);
    csv = csv.replace(/"/g, ''); // Remove double quotes

    fs.appendFile(templatesPath, `\n${csv}`, (err) => {
      if (err) {
        console.error('Error writing file:', err);
        res.status(500).send('Error writing file');
        return;
      }
      res.send('Template added successfully');
    });
  });
});

app.put('/templates', (req, res) => {
  const updatedTemplate = req.body;

  // Check if the template name is empty
  if (!updatedTemplate.TemplateName.trim()) {
    res.status(400).send('Template Name is required');
    return;
  }

  fs.readFile(templatesPath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading file:', err);
      res.status(500).send('Error reading file');
      return;
    }

    const templates = data.split('\n').map(row => {
      const fields = row.split(',');
      return fields.reduce((acc, field, index) => {
        if (index === 0) {
          acc.TemplateName = field.trim(); // Ensure TemplateName is correctly assigned
        } else {
          acc[`Field${index - 1}`] = field.trim(); // Adjust index to avoid overwriting TemplateName
        }
        return acc;
      }, {});
    });

    const index = templates.findIndex(template => template.TemplateName === updatedTemplate.TemplateName);
    if (index !== -1) {
      // Adjust field sequences
      const adjustedTemplate = { TemplateName: updatedTemplate.TemplateName };
      let fieldIndex = 0;
      Object.keys(updatedTemplate).forEach(key => {
        if (key !== 'TemplateName') {
          adjustedTemplate[`Field${fieldIndex}`] = updatedTemplate[key];
          fieldIndex++;
        }
      });
      templates[index] = adjustedTemplate;
    } else {
      templates.push(updatedTemplate);
    }

    // Ensure all fields are populated
    templates.forEach(template => {
      Object.keys(template).forEach(key => {
        if (!template[key].trim()) {
          template[key] = 'N/A'; // Assign a default value if the field is empty
        }
      });
    });

    const json2csvParser = new Parser({ header: true }); // Include headers
    let csv = json2csvParser.parse(templates);
    csv = csv.replace(/"/g, ''); // Remove double quotes

    fs.writeFile(templatesPath, csv, (err) => {
      if (err) {
        console.error('Error writing file:', err);
        res.status(500).send('Error writing file');
        return;
      }
      res.send('Template updated successfully');
    });
  });
});



// New endpoint to save CSV file
app.post('/save-file', (req, res) => {
  const { fileName, fileContent } = req.body;
  const filePath = path.join(__dirname, '/assets', fileName);

  fs.writeFile(filePath, fileContent, (err) => {
    if (err) {
      console.error('Error saving file:', err);
      res.status(500).send('Error saving file');
      return;
    }
    res.send('File saved successfully');
  });
});


app.get('/hosts/:fileName', (req, res) => {
  const fileName = req.params.fileName;
  const filePath = path.join(__dirname, '/assets', fileName);

  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading file:', err);
      res.status(500).send('Error reading file');
      return;
    }
    res.send(data);
  });
});


const { exec } = require('child_process');

app.get('/open-doc/:jobName', (req, res) => {
  const jobName = req.params.jobName;
  const directoryPath = '\\\\fra1isx01p\\Production Control'; // UNC path to network share
  const fileNamePattern = new RegExp(`${jobName}.*\\.docx`, 'i'); // Case-insensitive match

  fs.readdir(directoryPath, (err, files) => {
    if (err) {
      console.error('Error reading directory:', err);
      return res.status(500).send('Error reading directory');
    }

    const matchedFile = files.find(file => fileNamePattern.test(file));
    if (!matchedFile) {
      console.error(`No matching file found for jobName: ${jobName}`);
      return res.status(404).send('No matching document found');
    }

    const filePath = path.join(directoryPath, matchedFile);
    console.log('Opening file:', filePath);

    exec(`start "" "${filePath}"`, (err) => {
      if (err) {
        console.error('Failed to open file:', err);
        return res.status(500).send('Failed to open file');
      }
      res.send('File opened successfully');
    });
  });
});






app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
