import { Component, OnInit, Input } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-deployment',
  templateUrl: './deployment.component.html',
  styleUrls: ['./deployment.component.css']
})
export class DeploymentComponent implements OnInit {
  @Input() data: any;
  prodTasks: any[] = [];
  selectedTask: any;
  taskDetails: any;
  taskDetailKeys: string[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    // Load initial data if necessary
  }

  displayProdTasks() {
    const token = prompt('Enter Bearer Token');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    const url = `${environment.baseUrls.prod}${environment.apiEndpoints.tasks}`;
    this.http.get(url, { headers })
      .subscribe((data: any) => {
        this.prodTasks = data.items;
      });
  }

  moreAboutTask() {
    const token = prompt('Enter Bearer Token');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    const url = `${environment.baseUrls.prod}${environment.apiEndpoints.taskDetails(this.selectedTask.id)}`;
    this.http.get(url, { headers })
      .subscribe((data: any) => {
        this.taskDetails = data;
        this.taskDetailKeys = Object.keys(data);
      });
  }

  found() {
    // Enable button to go to next step "SDM Handover"
  }
}
