
import { Component, OnInit, Input, ChangeDetectorRef  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { ControlMComponent } from '../control-m/control-m.component';
import { ChangeManagementComponent } from '../change-management/change-management.component';
import { DeploymentComponent } from '../deployment/deployment.component';
import { SDMComponent } from '../sdm/sdm.component';
import { NamingStandardsComponent } from '../naming-standards/naming-standards.component';
import { CodeReviewComponent } from '../code-review/code-review.component';
import { DevelopmentComponent } from '../development/development.component';
import { TestingComponent } from '../testing/testing.component';
import * as Papa from 'papaparse'; // Import PapaParse
import { Router } from '@angular/router'; // Import Router
import axios from 'axios';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  @Input() data: any;
  rowData: any;
  rowKeys: string[] = [];
  xmlFiles: any = { qa: '', prod: '' };
  parameters: any[] = [];
  parameterFileFound: boolean = false;
  isParameterEditable: boolean = true;
  selectedTab: string = 'IDRG_Details';
  managedTransferContent: any = { qa: '', prod: '' };
  staticValues: string[] = [];
  frequencyValues: string[] = [];
  templateNames: string[] = [];
  templates: any[] = [];
  selectedNamingStandard: string = '';
  concatenatedString: string = '';
  miaTaskName: string = '';
  env: 'qa' | 'prod' = 'qa'; // or 'prod'

  sourceAppNameFilterQA: string = '';
  sourceAppNameFilterProd: string = '';
  sourceHostQA: string = '';
  sourceHostProd: string = '';
  sourceProtocolQA: string = '';
  sourceProtocolProd: string = '';
  sourcePortQA: string = '';
  sourcePortProd: string = '';

  targetAppNameFilterQA: string = '';
  targetAppNameFilterProd: string = '';
  targetHostQA: string = '';
  targetHostProd: string = '';
  targetProtocolQA: string = '';
  targetProtocolProd: string = '';
  targetPortQA: string = '';
  targetPortProd: string = '';

  sourceAppNamesQA: { Name: string; hostUnc: string; Type: string; subdetail: string }[] = [];
  sourceAppNamesProd: { Name: string; hostUnc: string; Type: string; subdetail: string }[] = [];
  targetAppNamesQA: { Name: string; hostUnc: string; Type: string; subdetail: string }[] = [];
  targetAppNamesProd: { Name: string; hostUnc: string; Type: string; subdetail: string }[] = [];
  filteredSourceAppNamesQA: { Name: string; hostUnc: string; Type: string; subdetail: string }[] = [];
  filteredSourceAppNamesProd: { Name: string; hostUnc: string; Type: string; subdetail: string }[] = [];
  filteredTargetAppNamesQA: { Name: string; hostUnc: string; Type: string; subdetail: string }[] = [];
  filteredTargetAppNamesProd: { Name: string; hostUnc: string; Type: string; subdetail: string }[] = [];

  constructor(private route: ActivatedRoute, private http: HttpClient, private router: Router, private cdr: ChangeDetectorRef) {
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras.state;
    if (state && state.environment) {
      this.env = state.environment;
    } else {
      this.env = 'qa'; // Default to 'qa' if environment is not provided
    }
  }

  navigateToSourceSelection(env: 'qa' | 'prod') {
    this.router.navigate(['/source-selection'], { state: { environment: env } });
  }

  navigateToTargetSelection(env: 'qa' | 'prod') {
    this.router.navigate(['/source-selection'], { state: { environment: env } });

  }


  ngOnInit() {
    this.initializeComponent();
  }

  initializeComponent() {
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras.state || history.state;

    this.env = state.environment || 'qa'; // Ensure environment is set

    this.rowData = state.data || {}; // Ensure rowData is initialized
    if (this.rowData) {
      this.rowKeys = Object.keys(this.rowData);
    } else {
      console.error('rowData is undefined');
    }

    this.parameters = this.getDefaultParameters();
    this.loadXmlFiles();
    this.loadParameterFiles();
    this.loadStaticValues();
    this.loadTemplates();
    this.loadHostsCsv('qa'); // Load QA data
    this.loadHostsCsv('prod'); // Load Prod data
  }



navigateToDevelopment() {
  this.router.navigate(['/development']);
}


  loadXmlFiles() {
    const transferId = this.rowData['TransferID'];
    const timestamp = new Date().getTime(); // Cache-busting parameter

    this.http.get(`${environment.qaXmlPath}${transferId}.xml?ts=${timestamp}`, { responseType: 'text' })
      .subscribe(data => {
        this.xmlFiles.qa = data;
        this.updateTransferDataType('qa');
        this.extractManagedTransferContent('qa');
        this.cdr.detectChanges(); // Trigger change detection
      }, error => console.error('Error loading QA XML:', error));

    this.http.get(`${environment.prodXmlPath}${transferId}.xml?ts=${timestamp}`, { responseType: 'text' })
      .subscribe(data => {
        this.xmlFiles.prod = data;
        this.updateTransferDataType('prod');
        this.extractManagedTransferContent('prod');
        this.cdr.detectChanges(); // Trigger change detection
      }, error => console.error('Error loading Prod XML:', error));
  }


  extractManagedTransferContent(env: 'qa' | 'prod') {
    const xmlString = this.xmlFiles[env];
    if (!xmlString) {
      console.error(`XML data for ${env} environment is undefined`);
      return;
    }

    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlString, 'application/xml');

    if (xmlDoc.getElementsByTagName('parsererror').length > 0) {
      console.error(`Error parsing XML data for ${env} environment`);
      return;
    }

    const requestElement = xmlDoc.querySelector('request');
    if (!requestElement) {
      console.error(`request element not found in ${env} XML`);
      return;
    }

    this.managedTransferContent[env] = requestElement.outerHTML;
  }


showJobDocument() {
const jobName = this.rowData['JobName'];
const filePath = `file:///fra1isx01p/Production%20Control/${jobName}.docx`;
const wordLink = `ms-word:ofe|u|${filePath}`;
window.location.href = wordLink;

/*
  const jobName = this.rowData['JobName'];
  if (!jobName) {
    console.error('JobName is undefined');
    return;
  }

  fetch(`http://localhost:3000/open-doc/${encodeURIComponent(jobName)}`)
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to open document');
      }
      console.log('Document opened successfully');
    })
    .catch(error => {
      console.error('Error:', error);
    });

 */
}





  loadParameterFiles() {
    const jobName = this.rowData['JobName'];
    const transferId = this.rowData['TransferID'];
    this.http.get(`${environment.parameterPath}${jobName}_${transferId}_parametersheet.csv`, { responseType: 'text' })
      .subscribe(data => {
        this.parameterFileFound = true;
        this.parameters = this.parseCsv(data).map(param => ({
          name: param.name,
          qa: param.qa,
          prod: param.prod,
          editable: false
        }));
        this.updateParametersFromCsv();
      }, error => {
        this.parameterFileFound = false;
this.parameters = this.getDefaultParameters().map(param => {
  const isProductDomain = param.name === 'Product Domain';
  const isFrequency = param.name === 'Frequency';

  return {
    ...param,
    qa: isProductDomain ? this.rowData['Domain'] :
        isFrequency ? this.rowData['JobSchedule'] : param.qa,
    prod: isProductDomain ? this.rowData['Domain'] :
          isFrequency ? this.rowData['JobSchedule'] : param.prod,
    editable: true,
    options: isProductDomain ? this.staticValues :
             isFrequency ? this.frequencyValues : []
  };
});

        this.updateParametersFromCsv();
      });
  }

updateTransferDataType(env: 'qa' | 'prod') {
  const xmlString = this.xmlFiles[env];
  if (!xmlString) {
    console.error(`XML data for ${env} environment is undefined`);
    return;
  }

  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(xmlString, 'application/xml');

  if (xmlDoc.getElementsByTagName('parsererror').length > 0) {
    console.error(`Error parsing XML data for ${env} environment`);
    return;
  }

  const itemElement = xmlDoc.querySelector('item');
  if (!itemElement) {
    console.error(`Item element not found in ${env} XML`);
    return;
  }

  const modeValue = itemElement.getAttribute('mode');
  const transferDataType = modeValue === 'text' ? 'ASCII' : 'binary';

  const destinationElement = itemElement.querySelector('destination');
  if (!destinationElement) {
    console.error(`Destination element not found in ${env} XML`);
    return;
  }



  const fileExistAction = destinationElement.getAttribute('exist');
  const targetFileName = destinationElement.querySelector('file')?.textContent || '';


  const sourceElement = itemElement.querySelector('source');
  if (!sourceElement) {
    console.error(`Source element not found in ${env} XML`);
    return;
  }

  const fileDisposition = sourceElement.getAttribute('disposition');
  const sourceFileName = sourceElement.querySelector('file')?.textContent || '';


  if (!Array.isArray(this.parameters)) {
    console.error(`Parameters are not defined or not an array`);
    return;
  }

  // Update Parameters
  this.parameters = this.parameters.map(param => {
    if (param.name === 'Transfer Data Type') {
      return { ...param, [env]: transferDataType };
    } else if (param.name === 'File Exist Action') {
      return { ...param, [env]: fileExistAction };
    } else if (param.name === 'File Disposition (After Transfer)') {
      return { ...param, [env]: fileDisposition };
    } else if (param.name === 'Target File Name') {
      return { ...param, [env]: targetFileName };
    } else if (param.name === 'Source File Name') {
      return { ...param, [env]: sourceFileName };
    }
    return param;
  });

  this.cdr.detectChanges(); // Trigger change detection
}




generateCsv() {
  const jobName = this.rowData['JobName'];
  const transferId = this.rowData['TransferID'];
  const csvData = this.parameters.map(param => ({
    name: param.name,
    qa: param.qa,
    prod: param.prod
  }));

  const csvContent = this.convertToCsv(csvData);
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const fileName = `${jobName}_${transferId}_parametersheet.csv`;
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  // Send the CSV data to the server to save a copy
  this.http.post(`${environment.backendApiUrl}/save-file`, { fileName, fileContent: csvContent }, { responseType: 'text' })
    .subscribe(response => {
      console.log('File saved successfully');
    }, error => {
      console.error('Error saving file:', error);
    });
}

convertToCsv(data: any[]): string {
  if (!data || data.length === 0) {
    return '';
  }

  const headers = Object.keys(data[0]).join(',');
  const rows = data.map(row => {
    return Object.keys(row).map(key => `"${row[key]}"`).join(',');
  }).join('\n');

  return `${headers}\n${rows}`;
}


  updateParametersFromCsv() {
      const jobSchedule = this.rowData['JobSchedule'];
      const sourceLocation = this.rowData['SourceLocation'];
      const destinationLocation = this.rowData['DestinationLocation'];
      const encryptionRequired = sourceLocation.includes('pgp') || destinationLocation.includes('pgp') ? 'Y' : 'N';
      const encryptionType = encryptionRequired === 'Y' ? 'PGP' : 'NA';

      // Function to extract the file name from the source location
      const extractFileName = (path: string): string => {
          const sanitizedPath = path.replace(/\\/g, '/'); // Replace all backslashes with forward slashes
          return sanitizedPath.substring(sanitizedPath.lastIndexOf('/') + 1);
      };

      this.parameters = this.parameters.map(param => {
          if (param.name === 'Day and Time of Transfer' || param.name === 'Frequency') {
              return {
                  ...param,
                  qa: jobSchedule,
                  prod: jobSchedule
              };
          } else if (param.name === 'Encryption/Decryption Required') {
              return {
                  ...param,
                  qa: encryptionRequired,
                  prod: encryptionRequired
              };
          } else if (param.name === 'Encryption/Decryption Type') {
              return {
                  ...param,
                  qa: encryptionType,
                  prod: encryptionType
              };
          } else if (param.name === 'Target Folder Name') {
              return {
                  ...param,
                  qa: destinationLocation,
                  prod: destinationLocation
              };
          } else if (param.name === 'Source Folder') {
              return {
                  ...param,
                  qa: sourceLocation,
                  prod: sourceLocation
              };
          }  else {
              return param;
          }
      });
  }



loadStaticValues() {
  this.http.get(environment.staticvaluesPath, { responseType: 'text' })
    .subscribe(data => {
      const parsedData = this.parseCsv(data);
      this.staticValues = parsedData.map(item => item.product_domain).filter(value => value); // Filter out empty values
      this.frequencyValues = parsedData.map(item => item.frequency_name).filter(value => value); // Filter out empty values
      this.updateParameterOptions(); // Update parameter options
    }, error => {
      console.error('Error loading static values:', error);
    });
}

updateParameterOptions() {
  this.parameters = this.parameters.map(param => {
    if (param.name === 'Product Domain') {
      return { ...param, options: this.staticValues };
    } else if (param.name === 'Frequency') {
      return { ...param, options: this.frequencyValues };
    }
    return param;
  });
}

parseCsv(data: string): any[] {
  const results = [];
  Papa.parse(data, {
    header: true,
    skipEmptyLines: true,
    complete: (parsedData) => {
      results.push(...parsedData.data);
    }
  });
  return results;
}




  loadTemplateNames() {
    axios.get(`${environment.backendApiUrl}/template-names`)
      .then(response => {
        this.templateNames = response.data;
      })
      .catch(error => {
        console.error('Error fetching template names:', error);
      });
  }

loadTemplates() {
  axios.get(`${environment.backendApiUrl}/templates`)
    .then(response => {

      this.templates = response.data.split('\n').map(row => {
        const fields = row.split(',');
        return fields.reduce((acc, field, index) => {
          acc[`Field${index}`] = field.trim();
          return acc;
        }, { TemplateName: fields[0].trim() });
      }).filter(template => template.TemplateName); // Filter out templates with blank names
      // Extract template names and assign to templateNames
      this.templateNames = this.templates.map(template => template.TemplateName);
    })
    .catch(error => {
      console.error('Error fetching templates:', error);
    });
}

updateMiaTaskName() {
  this.parameters = this.parameters.map(param => {
    if (param.name === 'MIA Task Name') {
      const selectedTemplate = this.templates.find(template => template.TemplateName === this.selectedNamingStandard);
      if (selectedTemplate) {
        const concatenatedValues = Object.keys(selectedTemplate)
          .filter(key => key !== 'TemplateName')
          .map(key => this.rowData[key] || selectedTemplate[key] || key)
          .join('_');
        return {
          ...param,
          qa: concatenatedValues,
          prod: concatenatedValues
        };
      } else {
        return {
          ...param,
          qa: '',
          prod: ''
        };
      }
    }
    return param;
  });

  const selectedTemplate = this.templates.find(template => template.TemplateName === this.selectedNamingStandard);
  if (selectedTemplate) {
    const concatenatedValues = Object.keys(selectedTemplate)
      .filter(key => key !== 'TemplateName')
      .map(key => this.rowData[key] || selectedTemplate[key] || key)
      .join('_');
    this.concatenatedString = concatenatedValues;
    this.miaTaskName = concatenatedValues;
  } else {
    this.concatenatedString = '';
    this.miaTaskName = '';
  }
}




getDefaultParameters(): any[] {
  const parameters = [
    { name: 'S.NO', qa: '1', prod: '2' },
    { name: 'Environment', qa: 'QA', prod: 'Prod' },
    { name: 'Product Domain', qa: this.rowData['Domain'], prod: this.rowData['Domain'], options: [] },
    { name: 'Transfer Data Type', qa: '', prod: '' },
    { name: 'Encryption/Decryption Required', qa: 'N', prod: 'N' },
    { name: 'Encryption/Decryption Type', qa: '', prod: '' },
    { name: 'Day and Time of Transfer', qa: '', prod: '' },
    { name: 'Predecessor Job and/or Time', qa: '', prod: '' },
    { name: 'Source Server', qa: '', prod: '' },
    { name: 'Source Protocol', qa: '', prod: '' },
    { name: 'Source Host', qa: '', prod: '' },
    { name: 'Source Port', qa: '', prod: '' },
    { name: 'Source Folder', qa: '', prod: '' },
    { name: 'Source File Name/Dataset', qa: '', prod: '' },
    { name: 'Source Authentication Type', qa: '', prod: '' },
    { name: 'Source Authentication Service Account', qa: '', prod: '' },
    { name: 'File Disposition (After Transfer)', qa: '', prod: '' },
    { name: 'Target Server', qa: '', prod: '' },
    { name: 'Target Protocol', qa: '', prod: '' },
    { name: 'Target Host', qa: '', prod: '' },
    { name: 'Target Port', qa: '', prod: '' },
    { name: 'Target Folder Name', qa: '', prod: '' },
    { name: 'Target File Name', qa: '', prod: '' },
    { name: 'Target Authentication Type', qa: '', prod: '' },
    { name: 'Target Authentication Service Account', qa: '', prod: '' },
    { name: 'MIA Task Name', qa: '', prod: '' },
    { name: 'File Exist Action', qa: '', prod: '' },
    { name: 'Comments', qa: '', prod: '' },
    { name: 'Frequency', qa: '', prod: '', options: [] } // Initialize with empty options
  ];

  return Array.from(new Set(parameters.map(param => param.name)))
    .map(name => parameters.find(param => param.name === name));
}


loadHostsCsv(env: 'qa' | 'prod') {
  const fileName = `${env}_hosts.csv`;
  this.http.get(`${environment.backendApiUrl}/hosts/${fileName}`, { responseType: 'text' })
    .subscribe(data => {
      const parsedData = this.parseCsv(data);
      const filteredData = parsedData.filter(item => item.Type !== 'YYY');
      const sourceAppNames = Array.from(new Set(filteredData.map(item => ({
        Name: item.Name,
        hostUnc: item['host/unc'],
        Type: item.Type,
        subdetail: item.subdetail
      }))));
        // Sort the source app names alphabetically by Name
        sourceAppNames.sort((a, b) => a.Name.localeCompare(b.Name));

      if (env === 'qa') {
        this.sourceAppNamesQA = sourceAppNames;
        this.filteredSourceAppNamesQA = this.sourceAppNamesQA;
        this.targetAppNamesQA = sourceAppNames;
        this.filteredTargetAppNamesQA = this.targetAppNamesQA;
      } else {
        this.sourceAppNamesProd = sourceAppNames;
        this.filteredSourceAppNamesProd = this.sourceAppNamesProd;
        this.targetAppNamesProd = sourceAppNames;
        this.filteredTargetAppNamesProd = this.targetAppNamesProd;
      }
    }, error => {
      console.error('Error loading hosts CSV:', error);
    });
}


updateSourceFields(env: 'qa' | 'prod', selectedValue: string) {
  const selectedItem = this.sourceAppNamesQA.find(item => item.Name === selectedValue) || this.sourceAppNamesProd.find(item => item.Name === selectedValue);
  if (selectedItem) {
    const { hostUnc, Type, subdetail } = selectedItem;

    this.parameters = this.parameters.map(param => {
      if (param.name === 'Source Host') {
        return {
          ...param,
          [env]: hostUnc
        };
      } else if (param.name === 'Source Protocol') {
        return {
          ...param,
          [env]: Type
        };
      } else if (param.name === 'Source Port') {
        return {
          ...param,
          [env]: subdetail
        };
      }
      return param;
    });
  }
}
updateTargetFields(env: 'qa' | 'prod', selectedValue: string) {
  const selectedItem = this.targetAppNamesQA.find(item => item.Name === selectedValue) || this.targetAppNamesProd.find(item => item.Name === selectedValue);
  if (selectedItem) {
    const { hostUnc, Type, subdetail } = selectedItem;

    this.parameters = this.parameters.map(param => {
      if (param.name === 'Target Host') {
        return {
          ...param,
          [env]: hostUnc
        };
      } else if (param.name === 'Target Protocol') {
        return {
          ...param,
          [env]: Type
        };
      } else if (param.name === 'Target Port') {
        return {
          ...param,
          [env]: subdetail
        };
      }
      return param;
    });
  }
}

filterSourceAppNames(env: 'qa' | 'prod') {
  if (env === 'qa') {
    this.filteredSourceAppNamesQA = Array.from(new Set(this.sourceAppNamesQA.filter(item => item.Name.toLowerCase().includes(this.sourceAppNameFilterQA.toLowerCase()))));
  } else {
    this.filteredSourceAppNamesProd = Array.from(new Set(this.sourceAppNamesProd.filter(item => item.Name.toLowerCase().includes(this.sourceAppNameFilterProd.toLowerCase()))));
  }
}

filterTargetAppNames(env: 'qa' | 'prod') {
  if (env === 'qa') {
    this.filteredTargetAppNamesQA = this.targetAppNamesQA.filter(item => item.Name.toLowerCase().includes(this.targetAppNameFilterQA.toLowerCase()));
  } else {
    this.filteredTargetAppNamesProd = this.targetAppNamesProd.filter(item => item.Name.toLowerCase().includes(this.targetAppNameFilterProd.toLowerCase()));
  }
}


 updateSourceAppName(name: string, env: 'qa' | 'prod') {
    this.parameters = this.parameters.map(param => {
      if (param.name === 'Source App Name') {
        return {
          ...param,
          [env]: name
        };
      }
      return param;
    });
  }



  updateRow() {
    this.http.get(environment.csvPath, { responseType: 'text' })
      .subscribe((data) => {
        const rows = data.split('\n');
        const headers = rows[0].split(',');
        const updatedRows = rows.map((row, index) => {
          if (index === 0) return row; // Skip header row
          const columns = row.split(',');
          if (columns[0] === this.rowData[headers[0]]) {
            // Update the row data
            return headers.map(header => this.rowData[header]).join(',');
          }
          return row;
        });
        const updatedCsvData = updatedRows.join('\n');
        const blob = new Blob([updatedCsvData], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'data.csv';
        a.click();
        window.URL.revokeObjectURL(url);
        alert('Row updated successfully!');
        // Navigate back to index page
        window.location.href = '/';
      }, error => {
        alert('Failed to update row!');
      });
  }

  selectTab(tab: string) {
    this.selectedTab = tab;
  }
}




