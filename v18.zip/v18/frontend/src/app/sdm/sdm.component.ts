import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-sdm',
  templateUrl: './sdm.component.html',
  styleUrls: ['./sdm.component.css']
})
export class SDMComponent implements OnInit {
  @Input() data: any;
  sdmData: any = {
    projectName: 'MQFTE_To_MIA_Migration_domain',
    briefDescription: '',
    projectManager: 'Guru',
    gpsEsbManager: 'Mahesh Paluri',
    esbDevLead: 'Phanendra Kumar Meduri',
    // Initialize other fields similarly
  };

  ngOnInit() {
    // Load initial data if necessary
  }
}
