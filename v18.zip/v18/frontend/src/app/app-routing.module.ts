import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { DataDisplayComponent } from './data-display/data-display.component';
import { DetailsComponent } from './details/details.component';
import { ControlMComponent } from './control-m/control-m.component';
import { ChangeManagementComponent } from './change-management/change-management.component';
import { DeploymentComponent } from './deployment/deployment.component';
import { SDMComponent } from './sdm/sdm.component';
import { NamingStandardsComponent } from './naming-standards/naming-standards.component';
import { CodeReviewComponent } from './code-review/code-review.component';
import { DevelopmentComponent } from './development/development.component';
import { TestingComponent } from './testing/testing.component';
import { SourceSelectionComponent } from './source-selection/source-selection.component';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'user-management', component: UserManagementComponent },
  { path: 'data-display', component: DataDisplayComponent },
  { path: 'details', component: DetailsComponent },
  { path: 'control-m', component: ControlMComponent },
  { path: 'change-management', component: ChangeManagementComponent },
  { path: 'deployment', component: DeploymentComponent },
  { path: 'sdm', component: SDMComponent },
  { path: 'naming-standards', component: NamingStandardsComponent },
  { path: 'code-review', component: CodeReviewComponent },
  { path: 'development', component: DevelopmentComponent },
  { path: 'testing', component: TestingComponent },
  { path: 'source-selection', component: SourceSelectionComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
