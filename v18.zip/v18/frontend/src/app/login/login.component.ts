import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  gateCode: string = '';
  showHumorMessage: boolean = false; // Property to control humor message visibility

  constructor(private router: Router) {}

  enter() {
    if (this.gateCode) {
      this.router.navigate(['/data-display'], { state: { gateCode: this.gateCode } });
    }
  }

  guestEntry() {
    this.router.navigate(['/data-display'], { state: { gateCode: 'Guest' } });
  }

  forgotPassword() {
    this.showHumorMessage = true; // Show humor message when forgot password is clicked
    setTimeout(() => {
      this.showHumorMessage = false; // Hide humor message after 5 seconds
    }, 5000);
  }
}
