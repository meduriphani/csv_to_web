import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import * as Papa from 'papaparse';

@Component({
  selector: 'app-source-selection',
  templateUrl: './source-selection.component.html',
  styleUrls: ['./source-selection.component.css']
})
export class SourceSelectionComponent implements OnInit {
  environment: 'qa' | 'prod';
  hostsData: any[] = [];
  filteredData: any[] = [];
  currentPage: number = 1;
  pageSize: number = 50;
  filterText: string = '';
  username: string = '';
  password: string = '';
  activeTab: 'online' | 'offline' = 'offline';
  bearerToken: string = '';

  constructor(private router: Router, private http: HttpClient) {
    const navigation = this.router.getCurrentNavigation();
    this.environment = navigation?.extras.state?.environment;
    console.log('Environment in constructor:', this.environment);
  }

  ngOnInit() {
    console.log('Environment in ngOnInit:', this.environment);
    this.loadHostsCsv();
  }

  loadHostsCsv() {
    const fileName = `${this.environment}_hosts.csv`;

    this.http.get(`${environment.backendApiUrl}/hosts/${fileName}`, { responseType: 'text' })
      .subscribe(data => {
        const parsedData = this.parseCsv(data);
        this.hostsData = parsedData;
        this.filteredData = parsedData;
        console.log('Hosts data:', parsedData);
      }, error => {
        console.error('Error loading hosts CSV:', error);
      });
  }

  parseCsv(data: string): any[] {
    const results = [];
    Papa.parse(data, {
      header: true,
      skipEmptyLines: true,
      complete: (parsedData) => {
        results.push(...parsedData.data);
      }
    });
    return results;
  }

  filterData() {
    this.filteredData = this.hostsData.filter(item =>
      Object.keys(item).some(key => item[key].toString().toLowerCase().includes(this.filterText.toLowerCase()))
    );
    this.currentPage = 1;
  }

  clearFilter() {
    this.filterText = '';
    this.filteredData = this.hostsData;
    this.currentPage = 1;
  }

  selectSourceAppName(rowData: any) {
    if (!rowData) {
      console.error('rowData is undefined');
      return;
    }
    console.log('Navigating with environment:', this.environment);
    this.router.navigate(['/details'], { state: { selectedSourceAppName: rowData.Name, environment: this.environment, data: rowData } });
  }

  get paginatedData() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    return this.filteredData.slice(startIndex, startIndex + this.pageSize);
  }

  nextPage() {
    if (this.currentPage * this.pageSize < this.filteredData.length) {
      this.currentPage++;
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  setActiveTab(tab: 'online' | 'offline') {
    this.activeTab = tab;
  }




onSubmit() {
  const apiUrl = this.environment === 'qa' ? '/api' : '/api-prod';
  const url = `${apiUrl}/v1/token`;
  const server_host = environment.baseUrls[this.environment];
  alert(server_host);
  const data = `grant_type=password&password=${encodeURIComponent(this.password)}&server_host=${encodeURIComponent(server_host)}&username=${encodeURIComponent(this.username)}`;

console.log(`Request URL: ${apiUrl}`);
  console.log(`Request Data: ${data}`);

  this.http.post(url, data, {
    headers: {
      'accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  }).subscribe(response => {
    this.bearerToken = response['access_token'];
    console.log('Bearer Token:', this.bearerToken);
    alert(`Bearer Token: ${this.bearerToken}`);
  }, error => {
    console.error('Error fetching token:', error);
  });
}



}
