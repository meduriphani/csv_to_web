import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-control-m',
  templateUrl: './control-m.component.html',
  styleUrls: ['./control-m.component.css']
})
export class ControlMComponent implements OnInit {
  @Input() data: any;
  controlMData: any = {
    existingJobName: '',
    controlMJobName: '',
    briefJobDescription: '',
    productTeam: '',
    applName: '',
    bannerDivision: '',
    jobFunction: '',
    backupJob: '',
    frequency: '',
    lateSubmitAlert: '',
    longRunningAlert: '',
    comments: '',
    prodControlMScriptNameArgs: '', // Default value
    prodControlMAgentHostname: '',
    prodUserID: '',
    onCallInstructions: '',
    serviceGroup: '',
    priority: ''
  };

  productTeams: string[] = [];
  applNames: string[] = [];
  banners: string[] = [];
  jobFunctions: string[] = [];
  frequencies: string[] = [];
  prodControlMAgents: string[] = [
    '(msf1vftp02p & msf1vftp03p)P01IPMIALEGACYINT',
    '(wmia001p-wmia002p)(P01IPMIAI2INT)'
  ];

  constructor(private http: HttpClient) {}

  ngOnInit() {
  this.data = history.state.data;
    if (this.data) {
      this.controlMData = { ...this.data };
      this.controlMData.existingJobName = this.data.JobName;
      this.controlMData.prodControlMScriptNameArgs = 'D:\\TJXMiATaskTrigger\\miatasktrigger.bat prodtaskname 3600';
      this.controlMData.prodControlMAgentHostname = '(msf1vftp02p & msf1vftp03p)P01IPMIALEGACYINT',
      this.controlMData.prodUserID = 'CORP\\SA-MOVEIT-ESP-P',
      this.controlMData.onCallInstructions = 'Email ML-ESB Application Support Team <esb_appsupport@tjx.com> and call On ESB team.',
      this.controlMData.serviceGroup = 'AMS-ESB-L3',
      this.controlMData.priority = 'This is a Priority 2',
      this.controlMData.backupJob = 'No',
      this.controlMData.lateSubmitAlert = 'No',
      this.controlMData.longRunningAlert = 'No'
    }
    this.loadStaticValues();
  }

  loadStaticValues() {
    this.http.get(environment.staticvaluesPath, { responseType: 'text' }).subscribe(data => {
      const lines = data.split('\n');
      lines.forEach(line => {
        const [product_team, appl_name, banner, jobfunction, frequency_controlm] = line.split(',');
        if (product_team) this.productTeams.push(product_team);
        if (appl_name) this.applNames.push(appl_name);
        if (banner) this.banners.push(banner);
        if (jobfunction) this.jobFunctions.push(jobfunction);
        if (frequency_controlm) this.frequencies.push(frequency_controlm);
      });
    });
  }

  onProdControlMAgentChange() {
    if (this.controlMData.prodControlMAgentHostname === '(msf1vftp02p & msf1vftp03p)P01IPMIALEGACYINT') {
      this.controlMData.prodUserID = 'CORP\\SA-MOVEIT-ESP-P';
    } else if (this.controlMData.prodControlMAgentHostname === '(wmia001p-wmia002p)(P01IPMIAI2INT)') {
      this.controlMData.prodUserID = 'CORP\\SA-MOVEIT-ADMIN-PROD';
    }
  }

  createRequestCSV() {
    const csvData = Object.keys(this.controlMData).map(key => `${key},${this.controlMData[key]}`).join('\n');
    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${this.controlMData.controlMJobName}_control.csv`; // Dynamic file name
    a.click();
    window.URL.revokeObjectURL(url);
    alert('Request CSV created successfully!');
  }
}
