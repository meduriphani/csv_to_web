import '@angular/compiler';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DataDisplayComponent } from './data-display/data-display.component';
import { DetailsComponent } from './details/details.component';
import { ControlMComponent } from './control-m/control-m.component';
import { ChangeManagementComponent } from './change-management/change-management.component';
import { DeploymentComponent } from './deployment/deployment.component';
import { SDMComponent } from './sdm/sdm.component';
import { NamingStandardsComponent } from './naming-standards/naming-standards.component';
import { CodeReviewComponent } from './code-review/code-review.component';
import { DevelopmentComponent } from './development/development.component';
import { TestingComponent } from './testing/testing.component';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxPaginationModule } from 'ngx-pagination';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { NavigationComponent } from './shared/navigation/navigation.component';
import { SourceSelectionComponent } from './source-selection/source-selection.component';

@NgModule({
  declarations: [
    AppComponent,
    DataDisplayComponent,
    DetailsComponent,
    ControlMComponent,
    ChangeManagementComponent,
    DeploymentComponent,
    SDMComponent,
    NamingStandardsComponent,
    CodeReviewComponent,
    DevelopmentComponent,
    TestingComponent,
    LoginComponent,
    UserManagementComponent,
    NavigationComponent,
    SourceSelectionComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    NgxPaginationModule,
    MatTabsModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    CommonModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

