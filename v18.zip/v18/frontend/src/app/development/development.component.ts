import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import * as Papa from 'papaparse';

@Component({
  selector: 'app-development',
  templateUrl: './development.component.html',
  styleUrls: ['./development.component.css']
})
export class DevelopmentComponent implements OnInit {
  @Input() data: any;
  parameters: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.loadParameterFile();
  }

  loadParameterFile() {
    const jobName = this.data['JobName'];
    const transferId = this.data['TransferID'];
    const filePath = `${environment.parameterPath}${jobName}_${transferId}_parametersheet.csv`;

    this.http.get(filePath, { responseType: 'text' })
      .subscribe(data => {
        this.parameters = this.parseCsv(data);
      }, error => {
        console.error('Error loading parameter file:', error);
      });
  }

  parseCsv(data: string): any[] {
    const results = [];
    Papa.parse(data, {
      header: true,
      skipEmptyLines: true,
      complete: (parsedData) => {
        results.push(...parsedData.data);
      }
    });
    return results;
  }
}
